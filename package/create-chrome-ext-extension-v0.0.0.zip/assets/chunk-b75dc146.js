const e=document.querySelectorAll("div.loading-spinner");console.log(e);for(const o of e)o.remove();
